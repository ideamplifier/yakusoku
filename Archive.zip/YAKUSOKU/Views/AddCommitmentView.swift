import SwiftUI
import SwiftData

struct AddCommitmentView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var title = ""
    @State private var pros = ""
    @State private var cons = ""
    @State private var ifThen = ""
    @State private var showingExamples = false
    
    private var canSave: Bool {
        !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: JMSpacing.lg) {
                    titleSection
                    motivationSection
                    strategySection
                    
                    Spacer(minLength: JMSpacing.xxl)
                }
                .padding(JMSpacing.md)
            }
            .background(JMColor.paperGray)
            .jmNavigationBar(title: "새로운 약속")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("취소") {
                        dismiss()
                    }
                    .font(JMTypography.body())
                    .foregroundColor(JMColor.ink)
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("저장") {
                        saveCommitment()
                        HapticFeedback.success()
                    }
                    .font(JMTypography.body())
                    .fontWeight(.medium)
                    .foregroundColor(canSave ? JMColor.accent : JMColor.inkLighter)
                    .disabled(!canSave)
                }
            }
        }
    }
    
    private var titleSection: some View {
        JMCard {
            VStack(alignment: .leading, spacing: JMSpacing.sm) {
                Text("약속")
                    .font(JMTypography.caption())
                    .foregroundColor(JMColor.inkLight)
                
                TextField("예: 매일 운동하기", text: $title)
                    .font(JMTypography.body())
                    .padding(JMSpacing.sm)
                    .background(JMColor.paperGray)
                    .overlay(
                        RoundedRectangle(cornerRadius: JMRadius.sm)
                            .stroke(JMColor.line, lineWidth: 0.5)
                    )
                
                Text("구체적이고 측정 가능한 약속을 적어주세요")
                    .font(JMTypography.small())
                    .foregroundColor(JMColor.inkLighter)
            }
        }
    }
    
    private var motivationSection: some View {
        JMCard {
            VStack(alignment: .leading, spacing: JMSpacing.md) {
                Text("동기부여")
                    .font(JMTypography.heading())
                    .foregroundColor(JMColor.ink)
                
                VStack(alignment: .leading, spacing: JMSpacing.sm) {
                    HStack(spacing: JMSpacing.xs) {
                        Image(systemName: "checkmark.circle")
                            .font(.system(size: 14, weight: .light))
                            .foregroundColor(JMColor.success)
                        Text("지켰을 때 장점")
                            .font(JMTypography.caption())
                            .foregroundColor(JMColor.inkLight)
                    }
                    
                    TextEditor(text: $pros)
                        .scrollContentBackground(.hidden)
                        .font(JMTypography.body())
                        .frame(minHeight: 60)
                        .padding(JMSpacing.xs)
                        .background(JMColor.paperGray)
                        .overlay(
                            RoundedRectangle(cornerRadius: JMRadius.sm)
                                .stroke(JMColor.line, lineWidth: 0.5)
                        )
                }
                
                VStack(alignment: .leading, spacing: JMSpacing.sm) {
                    HStack(spacing: JMSpacing.xs) {
                        Image(systemName: "xmark.circle")
                            .font(.system(size: 14, weight: .light))
                            .foregroundColor(JMColor.error)
                        Text("어겼을 때 단점")
                            .font(JMTypography.caption())
                            .foregroundColor(JMColor.inkLight)
                    }
                    
                    TextEditor(text: $cons)
                        .scrollContentBackground(.hidden)
                        .font(JMTypography.body())
                        .frame(minHeight: 60)
                        .padding(JMSpacing.xs)
                        .background(JMColor.paperGray)
                        .overlay(
                            RoundedRectangle(cornerRadius: JMRadius.sm)
                                .stroke(JMColor.line, lineWidth: 0.5)
                        )
                }
            }
        }
    }
    
    private var strategySection: some View {
        JMCard {
            VStack(alignment: .leading, spacing: JMSpacing.md) {
                HStack {
                    Text("실행 의도")
                        .font(JMTypography.heading())
                        .foregroundColor(JMColor.ink)
                    
                    Spacer()
                    
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            showingExamples.toggle()
                        }
                    } label: {
                        Image(systemName: "questionmark.circle")
                            .font(.system(size: 18, weight: .light))
                            .foregroundColor(JMColor.inkLight)
                    }
                }
                
                VStack(alignment: .leading, spacing: JMSpacing.sm) {
                    Text("If-Then 전략")
                        .font(JMTypography.caption())
                        .foregroundColor(JMColor.inkLight)
                    
                    TextEditor(text: $ifThen)
                        .scrollContentBackground(.hidden)
                        .font(JMTypography.body())
                        .frame(minHeight: 60)
                        .padding(JMSpacing.xs)
                        .background(JMColor.paperGray)
                        .overlay(
                            RoundedRectangle(cornerRadius: JMRadius.sm)
                                .stroke(JMColor.line, lineWidth: 0.5)
                        )
                }
                
                if showingExamples {
                    VStack(alignment: .leading, spacing: JMSpacing.xs) {
                        Text("예시:")
                            .font(JMTypography.caption())
                            .foregroundColor(JMColor.inkLight)
                        
                        VStack(alignment: .leading, spacing: JMSpacing.xxs) {
                            Text("• 스트레스 받으면 → 5분 산책을 한다")
                            Text("• 야식이 땡기면 → 물 한 잔 마시고 10분 기다린다")
                            Text("• 편의점에 가면 → 과일과 물을 산다")
                        }
                        .font(JMTypography.small())
                        .foregroundColor(JMColor.inkLighter)
                    }
                    .padding(JMSpacing.sm)
                    .background(JMColor.paperDark)
                    .clipShape(RoundedRectangle(cornerRadius: JMRadius.sm))
                }
                
                Button {
                    addSampleCommitment()
                    HapticFeedback.light()
                } label: {
                    HStack {
                        Image(systemName: "wand.and.stars")
                            .font(.system(size: 14, weight: .light))
                        Text("예시 채우기")
                            .font(JMTypography.caption())
                    }
                    .foregroundColor(JMColor.inkLight)
                    .frame(maxWidth: .infinity)
                    .padding(JMSpacing.sm)
                    .overlay(
                        RoundedRectangle(cornerRadius: JMRadius.sm)
                            .stroke(JMColor.line, lineWidth: 0.5)
                    )
                }
            }
        }
    }
    
    private func saveCommitment() {
        let commitment = Commitment(
            title: title.trimmingCharacters(in: .whitespacesAndNewlines),
            pros: pros.isEmpty ? nil : pros,
            cons: cons.isEmpty ? nil : cons,
            ifThen: ifThen.isEmpty ? nil : ifThen,
            priority: 0
        )
        
        modelContext.insert(commitment)
        try? modelContext.save()
        dismiss()
    }
    
    private func addSampleCommitment() {
        title = "매일 30분 운동하기"
        pros = "체력이 좋아지고, 스트레스가 줄어들고, 건강해짐"
        cons = "체력이 떨어지고, 스트레스가 쌓이고, 건강이 나빠짐"
        ifThen = "퇴근하면 → 바로 운동복으로 갈아입는다"
    }
}

#Preview {
    AddCommitmentView()
        .modelContainer(for: Commitment.self)
}