import SwiftUI
import SwiftData
import Charts

struct WeeklyReportView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Query private var commitments: [Commitment]
    @Query private var checkins: [Checkin]
    
    @State private var selectedWeek = 0
    
    private var weekDates: [Date] {
        (0..<7).map { Date.daysAgo(6 - $0 - (selectedWeek * 7)) }
    }
    
    private var weeklyStats: WeeklyStatistics {
        calculateWeeklyStats()
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: JMSpacing.md) {
                    weekSelectorSection
                    overallScoreSection
                    
                    if !commitments.isEmpty {
                        commitmentsSection
                    }
                    
                    insightSection
                    
                    Spacer(minLength: JMSpacing.xxl)
                }
                .padding(JMSpacing.md)
            }
            .background(JMColor.paperGray)
            .jmNavigationBar(title: "주간 리포트")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("닫기") {
                        dismiss()
                    }
                    .font(JMTypography.body())
                    .foregroundColor(JMColor.ink)
                }
            }
        }
    }
    
    private var weekSelectorSection: some View {
        HStack {
            Button {
                selectedWeek += 1
                HapticFeedback.light()
            } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 16, weight: .light))
                    .foregroundColor(selectedWeek >= 4 ? JMColor.inkLighter : JMColor.ink)
            }
            .disabled(selectedWeek >= 4)
            
            Spacer()
            
            VStack(spacing: JMSpacing.xxs) {
                Text(selectedWeek == 0 ? "이번 주" : "\(selectedWeek)주 전")
                    .font(JMTypography.body())
                    .foregroundColor(JMColor.ink)
                Text(weekRangeText)
                    .font(JMTypography.caption())
                    .foregroundColor(JMColor.inkLight)
            }
            
            Spacer()
            
            Button {
                selectedWeek -= 1
                HapticFeedback.light()
            } label: {
                Image(systemName: "chevron.right")
                    .font(.system(size: 16, weight: .light))
                    .foregroundColor(selectedWeek <= 0 ? JMColor.inkLighter : JMColor.ink)
            }
            .disabled(selectedWeek <= 0)
        }
        .padding(JMSpacing.md)
        .background(JMColor.paper)
        .overlay(
            RoundedRectangle(cornerRadius: JMRadius.md)
                .stroke(JMColor.line, lineWidth: 0.5)
        )
    }
    
    private var overallScoreSection: some View {
        JMCard {
            VStack(spacing: JMSpacing.md) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: JMSpacing.xs) {
                        Text("달성률")
                            .font(JMTypography.caption())
                            .foregroundColor(JMColor.inkLight)
                        
                        HStack(alignment: .firstTextBaseline, spacing: 2) {
                            Text("\(Int(weeklyStats.successRate * 100))")
                                .font(.system(size: 36, weight: .light))
                                .foregroundColor(JMColor.ink)
                            Text("%")
                                .font(JMTypography.body())
                                .foregroundColor(JMColor.inkLight)
                        }
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing, spacing: JMSpacing.xs) {
                        statRow("잘함", count: weeklyStats.goodCount, color: JMColor.success)
                        statRow("보통", count: weeklyStats.mehCount, color: JMColor.warning)
                        statRow("못함", count: weeklyStats.poorCount, color: JMColor.error)
                    }
                }
                
                JMProgress(value: weeklyStats.successRate)
            }
        }
    }
    
    private func statRow(_ label: String, count: Int, color: Color) -> some View {
        HStack(spacing: JMSpacing.xs) {
            Circle()
                .fill(color)
                .frame(width: 6, height: 6)
            Text("\(label): \(count)")
                .font(JMTypography.caption())
                .foregroundColor(JMColor.inkLight)
        }
    }
    
    private var commitmentsSection: some View {
        VStack(spacing: JMSpacing.sm) {
            ForEach(commitments) { commitment in
                CommitmentWeekCard(
                    commitment: commitment,
                    weekDates: weekDates,
                    checkins: checkinsForCommitment(commitment)
                )
            }
        }
    }
    
    private var insightSection: some View {
        JMCard {
            VStack(alignment: .leading, spacing: JMSpacing.sm) {
                HStack(spacing: JMSpacing.xs) {
                    Image(systemName: insightIcon)
                        .font(.system(size: 16, weight: .light))
                        .foregroundColor(JMColor.ink)
                    Text("이번 주 돌아보기")
                        .font(JMTypography.heading())
                        .foregroundColor(JMColor.ink)
                }
                
                Text(insightText)
                    .font(JMTypography.body())
                    .foregroundColor(JMColor.inkLight)
                    .lineSpacing(4)
            }
        }
    }
    
    private var weekRangeText: String {
        let startDate = Date.daysAgo(6 + (selectedWeek * 7))
        let endDate = Date.daysAgo(selectedWeek * 7)
        
        let formatter = DateFormatter()
        formatter.dateFormat = "M/d"
        
        return "\(formatter.string(from: startDate)) - \(formatter.string(from: endDate))"
    }
    
    private var insightText: String {
        if weeklyStats.totalCheckins == 0 {
            return "이번 주는 기록이 없어요. 작은 시작이 큰 변화를 만들어요."
        } else if weeklyStats.successRate >= 0.8 {
            return "훌륭해요! 이번 주 목표를 잘 달성했어요. 다음 주도 이 기세를 유지해봐요!"
        } else if weeklyStats.successRate >= 0.5 {
            return "좋은 진전이 있었어요! 조금 더 노력하면 더 나은 결과를 얻을 수 있어요."
        } else {
            return "실패는 성공의 어머니예요. If-Then 전략을 다시 점검해보는 건 어떨까요?"
        }
    }
    
    private var insightIcon: String {
        if weeklyStats.totalCheckins == 0 {
            return "sparkles"
        } else if weeklyStats.successRate >= 0.8 {
            return "star"
        } else if weeklyStats.successRate >= 0.5 {
            return "arrow.up"
        } else {
            return "lightbulb"
        }
    }
    
    private func checkinsForCommitment(_ commitment: Commitment) -> [Checkin] {
        checkins.filter { checkin in
            checkin.commitmentID == commitment.id &&
            weekDates.contains { $0.yakusokuDayKey == checkin.dayKey }
        }
    }
    
    private func calculateWeeklyStats() -> WeeklyStatistics {
        var totalCheckins = 0
        var goodCount = 0
        var mehCount = 0
        var poorCount = 0
        
        for commitment in commitments {
            let weekCheckins = checkinsForCommitment(commitment)
            totalCheckins += weekCheckins.count
            
            for checkin in weekCheckins {
                switch checkin.rating {
                case .good: goodCount += 1
                case .meh: mehCount += 1
                case .poor: poorCount += 1
                }
            }
        }
        
        let possibleCheckins = commitments.count * 7
        let completionRate = possibleCheckins > 0 ? 
            Double(totalCheckins) / Double(possibleCheckins) : 0
        
        let successRate = totalCheckins > 0 ?
            Double(goodCount) / Double(totalCheckins) : 0
        
        return WeeklyStatistics(
            totalCheckins: totalCheckins,
            goodCount: goodCount,
            mehCount: mehCount,
            poorCount: poorCount,
            completionRate: completionRate,
            successRate: successRate
        )
    }
}

struct CommitmentWeekCard: View {
    let commitment: Commitment
    let weekDates: [Date]
    let checkins: [Checkin]
    
    private func ratingForDate(_ date: Date) -> Rating? {
        checkins.first { $0.dayKey == date.yakusokuDayKey }?.rating
    }
    
    var body: some View {
        JMCard {
            VStack(alignment: .leading, spacing: JMSpacing.sm) {
                Text(commitment.title)
                    .font(JMTypography.body())
                    .foregroundColor(JMColor.ink)
                
                HStack(spacing: JMSpacing.xs) {
                    ForEach(weekDates, id: \.self) { date in
                        VStack(spacing: JMSpacing.xxs) {
                            Text(date.weekdayString)
                                .font(JMTypography.small())
                                .foregroundColor(JMColor.inkLighter)
                            
                            if let rating = ratingForDate(date) {
                                Circle()
                                    .fill(colorForRating(rating))
                                    .frame(width: 24, height: 24)
                                    .overlay(
                                        Image(systemName: iconForRating(rating))
                                            .font(.system(size: 12, weight: .light))
                                            .foregroundColor(.white)
                                    )
                            } else {
                                Circle()
                                    .stroke(JMColor.line, lineWidth: 0.5)
                                    .frame(width: 24, height: 24)
                            }
                        }
                    }
                }
            }
        }
    }
    
    private func colorForRating(_ rating: Rating) -> Color {
        switch rating {
        case .good: return JMColor.success
        case .meh: return JMColor.warning
        case .poor: return JMColor.error
        }
    }
    
    private func iconForRating(_ rating: Rating) -> String {
        switch rating {
        case .good: return "checkmark"
        case .meh: return "minus"
        case .poor: return "xmark"
        }
    }
}

struct WeeklyStatistics {
    let totalCheckins: Int
    let goodCount: Int
    let mehCount: Int
    let poorCount: Int
    let completionRate: Double
    let successRate: Double
}

#Preview {
    WeeklyReportView()
        .modelContainer(for: [Commitment.self, Checkin.self])
}