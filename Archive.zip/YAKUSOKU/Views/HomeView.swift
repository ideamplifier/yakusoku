import SwiftUI
import SwiftData

struct HomeView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: [SortDescriptor(\Commitment.priority)]) 
    private var commitments: [Commitment]
    @Query private var checkins: [Checkin]
    
    @State private var showingAddCommitment = false
    @State private var showingWeeklyReport = false
    @State private var showingSettings = false
    @State private var selectedCommitment: Commitment?
    
    private var todayString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "M월 d일"
        formatter.locale = Locale(identifier: "ko_KR")
        return formatter.string(from: Date())
    }
    
    private var todayDay: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "d"
        return formatter.string(from: Date())
    }
    
    private var todayMonth: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "M월"
        formatter.locale = Locale(identifier: "ko_KR")
        return formatter.string(from: Date())
    }
    
    private var todayProgress: (completed: Int, total: Int) {
        let todayKey = Date().yakusokuDayKey
        let todayCheckins = checkins.filter { $0.dayKey == todayKey }
        let completed = todayCheckins.count
        let total = commitments.count
        return (completed, total)
    }
    
    private var weekProgress: Int {
        let weekDates = (0..<7).map { Date.daysAgo(6 - $0) }
        let weekKeys = weekDates.map { $0.yakusokuDayKey }
        let weekCheckins = checkins.filter { weekKeys.contains($0.dayKey) }
        let goodCount = weekCheckins.filter { $0.rating == .good }.count
        let totalPossible = commitments.count * 7
        return totalPossible > 0 ? Int((Double(goodCount) / Double(totalPossible)) * 100) : 0
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // 상단 정보 카드들
                    HStack(spacing: 16) {
                        // 날짜 카드
                        VStack(alignment: .leading, spacing: 4) {
                            Text(todayMonth)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text(todayDay)
                                .font(.system(size: 42, weight: .bold))
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(20)
                        .background(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .shadow(color: .black.opacity(0.05), radius: 10)
                        
                        // 이번 주 진행률
                        VStack(alignment: .trailing, spacing: 8) {
                            Text("이번 주")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            HStack(spacing: 4) {
                                Text("\(todayProgress.completed)/\(todayProgress.total)")
                                    .font(.title2.bold())
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 4)
                                    .background(Color.pink.opacity(0.1))
                                    .foregroundStyle(.pink)
                                    .clipShape(Capsule())
                            }
                            
                            // 진행률 바
                            GeometryReader { geo in
                                ZStack(alignment: .leading) {
                                    Capsule()
                                        .fill(Color.pink.opacity(0.1))
                                    
                                    if todayProgress.total > 0 {
                                        Capsule()
                                            .fill(Color.pink)
                                            .frame(width: geo.size.width * (Double(todayProgress.completed) / Double(todayProgress.total)))
                                    }
                                }
                            }
                            .frame(height: 8)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(20)
                        .background(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .shadow(color: .black.opacity(0.05), radius: 10)
                    }
                    .padding(.horizontal, 20)
                    
                    // 오늘의 약속 섹션
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Text("오늘의 약속")
                                .font(.headline)
                                .foregroundStyle(.primary)
                            
                            Spacer()
                            
                            Text("\(weekProgress)%")
                                .font(.title2.bold())
                                .foregroundStyle(.green)
                        }
                        .padding(.horizontal, 20)
                        
                        HStack {
                            Text("\(commitments.count)개 완료")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .padding(.horizontal, 20)
                            
                            Spacer()
                        }
                        
                        // 진행률 바
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                Capsule()
                                    .fill(Color.green.opacity(0.2))
                                
                                Capsule()
                                    .fill(Color.green)
                                    .frame(width: geo.size.width * (Double(weekProgress) / 100))
                            }
                        }
                        .frame(height: 12)
                        .padding(.horizontal, 20)
                        
                        // 약속 리스트
                        VStack(spacing: 0) {
                            if commitments.isEmpty {
                                EmptyStateView(showingAddCommitment: $showingAddCommitment)
                                    .padding(40)
                            } else {
                                ForEach(commitments) { commitment in
                                    CommitmentRow(commitment: commitment, checkins: checkinsForCommitment(commitment))
                                    
                                    if commitment != commitments.last {
                                        Divider()
                                            .padding(.leading, 20)
                                    }
                                }
                            }
                        }
                        .background(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .shadow(color: .black.opacity(0.05), radius: 10)
                        .padding(.horizontal, 20)
                    }
                    
                    Spacer(minLength: 30)
                }
                .padding(.top, 20)
            }
            .background(Color(hex: "#F8F8F8"))
            .navigationTitle("YAKUSOKU")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        showingWeeklyReport = true
                    } label: {
                        Image(systemName: "chart.bar")
                            .foregroundStyle(.primary)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack(spacing: 16) {
                        Button {
                            showingSettings = true
                        } label: {
                            Image(systemName: "gearshape")
                                .foregroundStyle(.primary)
                        }
                        
                        Button {
                            showingAddCommitment = true
                            HapticFeedback.light()
                        } label: {
                            Image(systemName: "plus.circle.fill")
                                .font(.title2)
                                .foregroundStyle(.primary)
                        }
                    }
                }
            }
            .sheet(isPresented: $showingAddCommitment) {
                AddCommitmentView()
            }
            .sheet(item: $selectedCommitment) { commitment in
                CommitmentDetailView(commitment: commitment)
            }
            .sheet(isPresented: $showingWeeklyReport) {
                WeeklyReportView()
            }
            .sheet(isPresented: $showingSettings) {
                SettingsView()
            }
        }
    }
    
    private func checkinsForCommitment(_ commitment: Commitment) -> [Checkin] {
        checkins.filter { $0.commitmentID == commitment.id }
    }
}

struct CommitmentRow: View {
    let commitment: Commitment
    let checkins: [Checkin]
    
    @Environment(\.modelContext) private var modelContext
    @State private var isChecked = false
    @State private var currentRating: Rating = .good
    
    private var todayKey: String {
        Date().yakusokuDayKey
    }
    
    private var todayCheckin: Checkin? {
        checkins.first { $0.dayKey == todayKey }
    }
    
    private var weekDots: [Bool?] {
        (0..<7).map { day in
            let date = Date.daysAgo(6 - day)
            let dayKey = date.yakusokuDayKey
            if let checkin = checkins.first(where: { $0.dayKey == dayKey }) {
                return checkin.rating == .good
            }
            return nil
        }
    }
    
    var body: some View {
        HStack(spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Text(commitment.title)
                    .font(.body)
                    .foregroundStyle(.primary)
                
                // 주간 진행 점들
                HStack(spacing: 4) {
                    ForEach(weekDots.indices, id: \.self) { index in
                        Circle()
                            .fill(weekDots[index] == true ? Color.green : 
                                  weekDots[index] == false ? Color.red.opacity(0.3) :
                                  Color.gray.opacity(0.2))
                            .frame(width: 6, height: 6)
                    }
                }
            }
            
            Spacer()
            
            // 토글 스위치와 상태 텍스트
            HStack(spacing: 12) {
                Text(isChecked ? ratingText(currentRating) : "")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                
                Toggle("", isOn: $isChecked)
                    .toggleStyle(CustomToggleStyle(rating: $currentRating))
                    .onChange(of: isChecked) { _, newValue in
                        updateCheckin(newValue ? currentRating : nil)
                    }
                    .onChange(of: currentRating) { _, newRating in
                        if isChecked {
                            updateCheckin(newRating)
                        }
                    }
            }
        }
        .padding(20)
        .contentShape(Rectangle())
        .onAppear {
            if let checkin = todayCheckin {
                isChecked = true
                currentRating = checkin.rating
            }
        }
    }
    
    private func ratingText(_ rating: Rating) -> String {
        switch rating {
        case .good: return "잘함"
        case .meh: return "보통"
        case .poor: return "못함"
        }
    }
    
    private func updateCheckin(_ rating: Rating?) {
        if let rating = rating {
            if let existingCheckin = todayCheckin {
                existingCheckin.rating = rating
            } else {
                let newCheckin = Checkin(
                    commitmentID: commitment.id,
                    dayKey: todayKey,
                    rating: rating
                )
                modelContext.insert(newCheckin)
            }
        } else {
            if let existingCheckin = todayCheckin {
                modelContext.delete(existingCheckin)
            }
        }
        
        try? modelContext.save()
        HapticFeedback.light()
    }
}

struct CustomToggleStyle: ToggleStyle {
    @Binding var rating: Rating
    
    func makeBody(configuration: Configuration) -> some View {
        ZStack {
            Capsule()
                .fill(configuration.isOn ? colorForRating(rating) : Color.gray.opacity(0.3))
                .frame(width: 60, height: 32)
            
            Circle()
                .fill(Color.white)
                .frame(width: 28, height: 28)
                .offset(x: configuration.isOn ? 14 : -14)
                .animation(.spring(response: 0.3, dampingFraction: 0.8), value: configuration.isOn)
        }
        .onTapGesture {
            if configuration.isOn {
                // 이미 켜져있으면 상태 순환: good -> meh -> poor -> good
                switch rating {
                case .good: rating = .meh
                case .meh: rating = .poor
                case .poor: rating = .good
                }
            } else {
                // 꺼져있으면 켜기
                configuration.isOn.toggle()
            }
        }
    }
    
    private func colorForRating(_ rating: Rating) -> Color {
        switch rating {
        case .good: return .green
        case .meh: return .yellow
        case .poor: return .red
        }
    }
}

struct EmptyStateView: View {
    @Binding var showingAddCommitment: Bool
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "leaf.circle")
                .font(.system(size: 60))
                .foregroundStyle(.green.opacity(0.5))
            
            VStack(spacing: 8) {
                Text("첫 약속을 만들어보세요")
                    .font(.headline)
                    .foregroundStyle(.primary)
                
                Text("작은 약속이 큰 변화를 만듭니다")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Button {
                showingAddCommitment = true
                HapticFeedback.medium()
            } label: {
                Label("약속 만들기", systemImage: "plus.circle.fill")
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                    .background(Color.green)
                    .foregroundStyle(.white)
                    .clipShape(Capsule())
            }
        }
    }
}

#Preview {
    HomeView()
        .modelContainer(for: [Commitment.self, Checkin.self])
}